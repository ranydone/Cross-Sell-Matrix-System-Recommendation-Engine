"""
Complete Product Selector Backend - SMART QUOTES FIX
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from openpyxl import load_workbook
import os
import re

app = Flask(__name__)
CORS(app)

# ALL 7 LOAN TYPES MAPPED
LOAN_TYPE_COLUMNS = {
    'New Car Finance': {'cross_sell': 'E', 'logic': 'F', 'seasoning': 'G'},
    'Used Car & Re-Finance': {'cross_sell': 'H', 'logic': 'I', 'seasoning': 'J'},
    'Top-Up Loans': {'cross_sell': 'K', 'logic': 'L', 'seasoning': 'M'},
    'Two Wheeler Finance': {'cross_sell': 'N', 'logic': 'O', 'seasoning': 'P'},
    'Car Lease': {'cross_sell': 'Q', 'logic': 'R', 'seasoning': 'S'},
    'Dealer Finance': {'cross_sell': 'T', 'logic': 'U', 'seasoning': 'V'},
    'Loan Against Property (LAP)': {'cross_sell': 'W', 'logic': 'X', 'seasoning': 'Y'},
}

def get_default_data():
    return {
        'entities': ['Individual', 'Non-Individual'],
        'individualTypes': ['Salaried', 'Self employed'],
        'nonIndividualTypes': [
            'Partnership firm', 'Proprietorship firm', 'Govt. / Public Sector',
            'Pvt. Limited Company', 'Limited Liability Partnership(LLP)', 'Public Limited Company'
        ],
        'customerTypes': ['New Customer', 'Existing Customer KMPL', 'Existing Customer KMB'],
        'individualIncomePrograms': [
            'Salaried – Formal', 'Salaried – Semi formal/Informal',
            'Self-Employed – Professional', 'Self-Employed – Business (Formal)',
            'Self-Employed – Business (Informal)'
        ],
        'nonIndividualIncomePrograms': ['program 1', 'program 2', 'program 3', 'program 4', 'program 5'],
        'loanTypes': list(LOAN_TYPE_COLUMNS.keys()),
        'seasoningOptions': []
    }

def extract_column_data(worksheet, column, start_row, end_row):
    values = []
    for row in range(start_row, end_row + 1):
        cell_value = worksheet[f'{column}{row}'].value
        if cell_value and str(cell_value).strip():
            values.append(str(cell_value).strip())
    return values

def parse_seasoning_range(seasoning_text):
    """Parse seasoning text to extract month range"""
    if not seasoning_text or seasoning_text == "None":
        return None
    
    text = str(seasoning_text).lower()
    
    if 'anytime' in text or 'event-driven' in text or 'recurring' in text:
        return (0, 999)
    
    numbers = re.findall(r'\d+', text)
    
    if 'day' in text and numbers:
        days = [int(n) for n in numbers]
        if len(days) >= 2:
            return (days[0] // 30, max(1, days[1] // 30))
        return (0, 1)
    
    if 'month' in text and numbers:
        months = [int(n) for n in numbers]
        if len(months) >= 2:
            return (months[0], months[1])
        return (months[0], months[0]) if months else None
    
    return (0, 999)

def extract_cross_sell_logic_parts(logic_text):
    """
    Extract Cue, Action, Variable Reward, and Investment
    HANDLES SMART QUOTES (curly quotes) from Excel!
    Smart quotes: " (U+201C) and " (U+201D)
    Regular quotes: " (U+0022)
    """
    if not logic_text:
        return {'cue': '', 'action': '', 'variable_reward': '', 'investment': ''}
    
    text = str(logic_text)
    parts = {}
    
    # Extract Cue - handles BOTH smart quotes and regular quotes
    # Pattern: ["\u201c] matches both " and "
    cue_match = re.search(r'Cue:\s*["\u201c]([^"\u201d]+)["\u201d]', text)
    parts['cue'] = cue_match.group(1).strip() if cue_match else ''
    
    # If Cue extraction failed, try without quotes
    if not parts['cue']:
        cue_match = re.search(r'Cue:\s*(.+?)\s*Action:', text, re.IGNORECASE)
        if cue_match:
            # Remove leading/trailing quotes if present
            cue_text = cue_match.group(1).strip()
            cue_text = cue_text.strip('"""\u201c\u201d')
            parts['cue'] = cue_text
    
    # Extract Action - text between "Action:" and "Variable Reward"
    action_match = re.search(r'Action:\s*(.+?)\s*Variable\s+Reward', text, re.IGNORECASE | re.DOTALL)
    if action_match:
        parts['action'] = action_match.group(1).strip()
    else:
        action_match = re.search(r'Action:\s*(.+?)(?:\s*Investment:|$)', text, re.IGNORECASE | re.DOTALL)
        parts['action'] = action_match.group(1).strip() if action_match else ''
    
    # Extract Variable Reward - between Variable Reward and Investment
    reward_match = re.search(r'Variable\s+Reward[^:]*:\s*(.+?)\s*Investment:', text, re.IGNORECASE | re.DOTALL)
    if reward_match:
        parts['variable_reward'] = reward_match.group(1).strip()
    else:
        reward_match = re.search(r'Variable\s+Reward[^:]*:\s*(.+?)$', text, re.IGNORECASE | re.DOTALL)
        parts['variable_reward'] = reward_match.group(1).strip() if reward_match else ''
    
    # Extract Investment - everything after "Investment:"
    investment_match = re.search(r'Investment:\s*(.+?)$', text, re.IGNORECASE | re.DOTALL)
    parts['investment'] = investment_match.group(1).strip() if investment_match else ''
    
    return parts

def find_matching_products(filepath, loan_type, seasoning_months):
    """Find matching products from Existing Matrix"""
    try:
        wb = load_workbook(filepath)
        
        if 'Existing Matrix' not in wb.sheetnames:
            return [], "Sheet 'Existing Matrix' not found"
        
        ws = wb['Existing Matrix']
        
        if loan_type not in LOAN_TYPE_COLUMNS:
            return [], f"Loan type '{loan_type}' not supported"
        
        cols = LOAN_TYPE_COLUMNS[loan_type]
        matching_products = []
        
        for row in range(2, ws.max_row + 1):
            cross_sell = ws[f"{cols['cross_sell']}{row}"].value
            
            if not cross_sell:
                continue
            
            cross_sell_str = str(cross_sell).strip().upper()
            if cross_sell_str not in ['YES', 'YES (STRONG)', 'CONDITIONAL']:
                continue
            
            seasoning_text = ws[f"{cols['seasoning']}{row}"].value
            seasoning_range = parse_seasoning_range(seasoning_text)
            
            if seasoning_range:
                min_m, max_m = seasoning_range
                if not (min_m <= seasoning_months <= max_m):
                    continue
            
            logic_text = ws[f"{cols['logic']}{row}"].value
            logic_parts = extract_cross_sell_logic_parts(logic_text)
            
            product_info = {
                'category': str(ws[f'A{row}'].value or ''),
                'product_type': str(ws[f'B{row}'].value or ''),
                'product_name': str(ws[f'C{row}'].value or ''),
                'target_audience': str(ws[f'D{row}'].value or ''),
                'cross_sell_status': str(cross_sell),
                'seasoning_range': str(seasoning_text or ''),
                'cue': logic_parts['cue'],
                'action': logic_parts['action'],
                'variable_reward': logic_parts['variable_reward'],
                'investment': logic_parts['investment']
            }
            
            matching_products.append(product_info)
        
        wb.close()
        return matching_products, None
    except Exception as e:
        return [], str(e)

def load_excel_data(filepath):
    """Load data from master sheet"""
    try:
        wb = load_workbook(filepath)
        
        sheet_name = next((n for n in wb.sheetnames if n.lower() == 'master'), None)
        if not sheet_name:
            return None, "Sheet 'master' not found"
        
        ws = wb[sheet_name]
        
        data = {
            'entities': ['Individual', 'Non-Individual'],
            'individualTypes': extract_column_data(ws, 'E', 3, 8),
            'nonIndividualTypes': extract_column_data(ws, 'H', 3, 8),
            'customerTypes': extract_column_data(ws, 'C', 3, 5),
            'individualIncomePrograms': extract_column_data(ws, 'G', 3, 8),
            'nonIndividualIncomePrograms': extract_column_data(ws, 'J', 3, 8),
            'loanTypes': list(LOAN_TYPE_COLUMNS.keys()),
            'seasoningOptions': []
        }
        
        wb.close()
        return data, None
    except Exception as e:
        return None, str(e)

@app.route('/api/data', methods=['GET'])
def get_data():
    return jsonify(get_default_data())

@app.route('/api/upload', methods=['POST'])
def upload_excel():
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if not file.filename or not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'error': 'Invalid file'}), 400
    
    filepath = os.path.join('uploads', file.filename)
    os.makedirs('uploads', exist_ok=True)
    file.save(filepath)
    
    data, error = load_excel_data(filepath)
    
    if error:
        try:
            os.remove(filepath)
        except:
            pass
        return jsonify({'error': error}), 400
    
    return jsonify(data)

@app.route('/api/match-products', methods=['POST'])
def match_products():
    data = request.json
    loan_type = data.get('loanType')
    seasoning_months = data.get('seasoningMonths')
    
    if not loan_type or seasoning_months is None:
        return jsonify({'error': 'Missing parameters'}), 400
    
    try:
        seasoning_months = int(seasoning_months)
    except:
        return jsonify({'error': 'Seasoning must be a number'}), 400
    
    filepath = 'uploads/products.xlsx' if os.path.exists('uploads/products.xlsx') else 'products.xlsx'
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'No Excel file available'}), 400
    
    products, error = find_matching_products(filepath, loan_type, seasoning_months)
    
    if error:
        return jsonify({'error': error}), 400
    
    return jsonify({
        'loan_type': loan_type,
        'seasoning_months': seasoning_months,
        'matching_products': products,
        'count': len(products)
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'ok',
        'supported_loan_types': list(LOAN_TYPE_COLUMNS.keys()),
        'total': len(LOAN_TYPE_COLUMNS),
        'smart_quotes_support': True
    })

if __name__ == '__main__':
    print("🚀 Product Selector Backend - SMART QUOTES FIXED")
    print("📡 http://localhost:5000")
    print(f"✅ {len(LOAN_TYPE_COLUMNS)} Loan Types")
    print("✅ Smart Quotes Support Enabled")
    app.run(debug=True, port=5000)
