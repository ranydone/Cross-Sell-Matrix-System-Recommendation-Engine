"""
Flask Backend API for Product Selector with Product Matching
Reads from "master" sheet and matches products from "Existing Matrix"
"""

from flask import Flask, jsonify, request
from flask_cors import CORS
from openpyxl import load_workbook
import os
import re

app = Flask(__name__)
CORS(app)

# Loan type to column mapping in Existing Matrix
LOAN_TYPE_COLUMNS = {
    'New Car Finance': {'cross_sell': 'E', 'logic': 'F', 'seasoning': 'G'},
    'Used Car & Re-Finance': {'cross_sell': 'H', 'logic': 'I', 'seasoning': 'J'},
    'Top-Up Loans': {'cross_sell': 'J', 'logic': 'K', 'seasoning': 'L'},
    'Two Wheeler Finance': {'cross_sell': 'L', 'logic': 'M', 'seasoning': 'N'},
    'Car Lease': {'cross_sell': 'N', 'logic': 'O', 'seasoning': 'P'},
    'Dealer Finance': {'cross_sell': 'P', 'logic': 'Q', 'seasoning': 'R'},
    'Loan Against Property (LAP)': {'cross_sell': 'R', 'logic': 'S', 'seasoning': 'T'},
}

def get_default_data():
    return {
        'entities': ['Individual', 'Non-Individual'],
        'individualTypes': ['Salaried', 'Self employed'],
        'nonIndividualTypes': [
            'Partnership firm',
            'Proprietorship firm',
            'Govt. / Public Sector',
            'Pvt. Limited Company',
            'Limited Liability Partnership(LLP)',
            'Public Limited Company'
        ],
        'customerTypes': ['New Customer', 'Existing Customer KMPL', 'Existing Customer KMB'],
        'individualIncomePrograms': [
            'Salaried – Formal',
            'Salaried – Semi formal/Informal',
            'Self-Employed – Professional',
            'Self-Employed – Business (Formal)',
            'Self-Employed – Business (Informal)'
        ],
        'nonIndividualIncomePrograms': [
            'program 1', 'program 2', 'program 3', 'program 4', 'program 5'
        ],
        'loanTypes': [
            'New Car Finance',
            'Used Car & Re-Finance',
            'Top-Up Loans',
            'Two Wheeler Finance',
            'Car Lease',
            'Dealer Finance',
            'Loan Against Property (LAP)'
        ],
        'seasoningOptions': []  # Will be manual entry in months
    }

def extract_column_data(worksheet, column, start_row, end_row):
    values = []
    for row in range(start_row, end_row + 1):
        cell_value = worksheet[f'{column}{row}'].value
        if cell_value and str(cell_value).strip():
            values.append(str(cell_value).strip())
    return values

def parse_seasoning_range(seasoning_text):
    """
    Parse seasoning text to get month range
    Examples:
    - "Day 0–30" -> (0, 1)
    - "Month 6–18" -> (6, 18)
    - "Month 3–9" -> (3, 9)
    - "Anytime" -> (0, 999)
    """
    if not seasoning_text or seasoning_text == "None":
        return None
    
    seasoning_text = str(seasoning_text).lower()
    
    if 'anytime' in seasoning_text or 'event-driven' in seasoning_text:
        return (0, 999)
    
    if 'recurring' in seasoning_text or 'every' in seasoning_text:
        return (0, 999)
    
    # Extract numbers
    numbers = re.findall(r'\d+', seasoning_text)
    
    if 'day' in seasoning_text and numbers:
        # Convert days to months (approximate)
        days = [int(n) for n in numbers]
        if len(days) >= 2:
            return (days[0] // 30, max(1, days[1] // 30))
        return (0, 1)
    
    if 'month' in seasoning_text and numbers:
        months = [int(n) for n in numbers]
        if len(months) >= 2:
            return (months[0], months[1])
        elif len(months) == 1:
            return (months[0], months[0])
    
    return (0, 999)

def extract_cross_sell_logic_parts(logic_text):
    """
    Extract Cue, Action, Variable Reward, and Investment from cross-sell logic
    """
    if not logic_text:
        return {'cue': '', 'action': '', 'variable_reward': '', 'investment': ''}
    
    text = str(logic_text)
    parts = {}
    
    # Extract Cue
    cue_match = re.search(r'Cue:\s*"([^"]+)"', text)
    parts['cue'] = cue_match.group(1) if cue_match else ''
    
    # Extract Action
    action_match = re.search(r'Action:\s*"([^"]+)"', text)
    parts['action'] = action_match.group(1) if action_match else ''
    
    # Extract Variable Reward
    reward_match = re.search(r'Variable Reward:\s*"([^"]+)"', text)
    parts['variable_reward'] = reward_match.group(1) if reward_match else ''
    
    # Extract Investment
    investment_match = re.search(r'Investment:\s*"([^"]+)"', text)
    parts['investment'] = investment_match.group(1) if investment_match else ''
    
    return parts

def find_matching_products(filepath, loan_type, seasoning_months):
    """
    Find matching products from Existing Matrix based on loan type and seasoning
    """
    try:
        wb = load_workbook(filepath)
        
        if 'Existing Matrix' not in wb.sheetnames:
            return [], "Sheet 'Existing Matrix' not found"
        
        ws = wb['Existing Matrix']
        
        # Get column mapping for this loan type
        if loan_type not in LOAN_TYPE_COLUMNS:
            return [], f"Loan type '{loan_type}' not found in mapping"
        
        cols = LOAN_TYPE_COLUMNS[loan_type]
        cross_sell_col = cols['cross_sell']
        logic_col = cols['logic']
        seasoning_col = cols['seasoning']
        
        matching_products = []
        
        # Start from row 2 (skip header)
        for row in range(2, ws.max_row + 1):
            # Get cross-sell indicator (YES/NO/CONDITIONAL)
            cross_sell = ws[f'{cross_sell_col}{row}'].value
            
            if not cross_sell or str(cross_sell).strip().upper() not in ['YES', 'YES (STRONG)', 'CONDITIONAL']:
                continue
            
            # Get seasoning range
            seasoning_text = ws[f'{seasoning_col}{row}'].value
            seasoning_range = parse_seasoning_range(seasoning_text)
            
            # Check if user's seasoning falls within range
            if seasoning_range:
                min_months, max_months = seasoning_range
                if not (min_months <= seasoning_months <= max_months):
                    continue
            
            # Get product details
            category = ws[f'A{row}'].value
            product_type = ws[f'B{row}'].value
            product_name = ws[f'C{row}'].value
            target_audience = ws[f'D{row}'].value
            logic_text = ws[f'{logic_col}{row}'].value
            
            # Parse cross-sell logic
            logic_parts = extract_cross_sell_logic_parts(logic_text)
            
            product_info = {
                'category': str(category) if category else '',
                'product_type': str(product_type) if product_type else '',
                'product_name': str(product_name) if product_name else '',
                'target_audience': str(target_audience) if target_audience else '',
                'cross_sell_status': str(cross_sell),
                'seasoning_range': seasoning_text,
                'cue': logic_parts['cue'],
                'action': logic_parts['action'],
                'variable_reward': logic_parts['variable_reward'],
                'investment': logic_parts['investment'],
                'full_logic': str(logic_text) if logic_text else ''
            }
            
            matching_products.append(product_info)
        
        wb.close()
        return matching_products, None
        
    except Exception as e:
        return [], str(e)

def load_excel_data(filepath):
    """Load data from master sheet"""
    try:
        wb = load_workbook(filepath)
        
        sheet_name = None
        for name in wb.sheetnames:
            if name.lower() == 'master':
                sheet_name = name
                break
        
        if not sheet_name:
            return None, "Sheet 'master' not found in Excel file"
        
        ws = wb[sheet_name]
        
        data = {
            'entities': ['Individual', 'Non-Individual'],
            'individualTypes': extract_column_data(ws, 'E', 3, 8),
            'nonIndividualTypes': extract_column_data(ws, 'H', 3, 8),
            'customerTypes': extract_column_data(ws, 'C', 3, 5),
            'individualIncomePrograms': extract_column_data(ws, 'G', 3, 8),
            'nonIndividualIncomePrograms': extract_column_data(ws, 'J', 3, 8),
            'loanTypes': extract_column_data(ws, 'K', 2, 9),
            'seasoningOptions': []  # Manual entry
        }
        
        wb.close()
        return data, None
    except Exception as e:
        return None, str(e)

# API Routes
@app.route('/api/data', methods=['GET'])
def get_data():
    """Get default data"""
    return jsonify(get_default_data())

@app.route('/api/upload', methods=['POST'])
def upload_excel():
    """Upload and parse Excel file"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not file.filename.endswith(('.xlsx', '.xls')):
        return jsonify({'error': 'Invalid file type'}), 400
    
    filepath = os.path.join('uploads', file.filename)
    os.makedirs('uploads', exist_ok=True)
    file.save(filepath)
    
    data, error = load_excel_data(filepath)
    
    # Keep file for product matching
    # Don't delete it yet
    
    if error:
        try:
            os.remove(filepath)
        except:
            pass
        return jsonify({'error': error}), 400
    
    return jsonify(data)

@app.route('/api/match-products', methods=['POST'])
def match_products():
    """Find matching products based on loan type and seasoning"""
    data = request.json
    
    loan_type = data.get('loanType')
    seasoning_months = data.get('seasoningMonths')
    
    if not loan_type:
        return jsonify({'error': 'Loan type is required'}), 400
    
    if seasoning_months is None:
        return jsonify({'error': 'Seasoning (months) is required'}), 400
    
    try:
        seasoning_months = int(seasoning_months)
    except:
        return jsonify({'error': 'Seasoning must be a number'}), 400
    
    # Use uploaded file or default
    filepath = 'uploads/products.xlsx'
    if not os.path.exists(filepath):
        # Try to use the provided products.xlsx
        filepath = 'products.xlsx'
    
    if not os.path.exists(filepath):
        return jsonify({'error': 'No Excel file available. Please upload products.xlsx'}), 400
    
    products, error = find_matching_products(filepath, loan_type, seasoning_months)
    
    if error:
        return jsonify({'error': error}), 400
    
    return jsonify({
        'loan_type': loan_type,
        'seasoning_months': seasoning_months,
        'matching_products': products,
        'count': len(products)
    })

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'ok',
        'message': 'Backend is running',
        'sheet': 'master',
        'features': ['product_matching', 'seasoning_months']
    })

if __name__ == '__main__':
    print("🚀 Starting Flask Backend...")
    print("📡 API available at: http://localhost:5000")
    print("📊 Reading from 'master' sheet")
    print("🎯 Product matching from 'Existing Matrix' sheet")
    print("📊 Endpoints:")
    print("   - GET  /api/data - Get default data")
    print("   - POST /api/upload - Upload Excel file")
    print("   - POST /api/match-products - Find matching products")
    print("   - GET  /api/health - Health check")
    app.run(debug=True, port=5000)
