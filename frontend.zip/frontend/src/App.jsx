import React from 'react'
import ProductSelector from './components/ProductSelector'

function App() {
  return <ProductSelector />
}

export default App
