import React, { useState, useEffect } from 'react';
import { ChevronDown, Upload, FileSpreadsheet, RefreshCw, Server, Search, Package, TrendingUp, DollarSign, Target, Clock } from 'lucide-react';
import axios from 'axios';

const API_URL = 'http://localhost:5000/api';

const ProductSelector = () => {
  const [selections, setSelections] = useState({
    entity: '', entityType: '', customerType: '', customerIncomeCategory: '', loanType: '', seasoningMonths: ''
  });
  const [data, setData] = useState(null);
  const [isCustomData, setIsCustomData] = useState(false);
  const [fileName, setFileName] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [backendStatus, setBackendStatus] = useState('checking');
  const [matchingProducts, setMatchingProducts] = useState(null);
  const [isSearching, setIsSearching] = useState(false);
  const [showResults, setShowResults] = useState(false);

  useEffect(() => {
    checkBackendHealth();
    loadDefaultData();
  }, []);

  const checkBackendHealth = async () => {
    try {
      await axios.get(`${API_URL}/health`);
      setBackendStatus('connected');
    } catch (err) {
      setBackendStatus('disconnected');
      setError('⚠️ Backend offline');
    }
  };

  const loadDefaultData = async () => {
    try {
      const response = await axios.get(`${API_URL}/data`);
      setData(response.data);
    } catch (err) {
      console.error(err);
    }
  };

  const handleFileUpload = async (event) => {
    const file = event.target.files[0];
    if (!file) return;
    setIsLoading(true);
    setError('');
    try {
      const formData = new FormData();
      formData.append('file', file);
      const response = await axios.post(`${API_URL}/upload`, formData);
      setData(response.data);
      setIsCustomData(true);
      setFileName(file.name);
      setSelections({ entity: '', entityType: '', customerType: '', customerIncomeCategory: '', loanType: '', seasoningMonths: '' });
    } catch (err) {
      setError(err.response?.data?.error || 'Upload failed');
    } finally {
      setIsLoading(false);
    }
  };

  const handleResetData = async () => {
    await loadDefaultData();
    setIsCustomData(false);
    setFileName('');
    setError('');
    setMatchingProducts(null);
    setShowResults(false);
    setSelections({ entity: '', entityType: '', customerType: '', customerIncomeCategory: '', loanType: '', seasoningMonths: '' });
  };

  const getEntityTypes = () => {
    if (!data) return [];
    return selections.entity === 'Individual' ? data.individualTypes : 
           selections.entity === 'Non-Individual' ? data.nonIndividualTypes : [];
  };

  const getIncomePrograms = () => {
    if (!data) return [];
    return selections.entity === 'Individual' ? data.individualIncomePrograms : 
           selections.entity === 'Non-Individual' ? data.nonIndividualIncomePrograms : [];
  };

  const handleEntityChange = (value) => {
    setSelections({ ...selections, entity: value, entityType: '', customerIncomeCategory: '' });
  };

  const handleChange = (field, value) => {
    setSelections({ ...selections, [field]: value });
  };

  const showLoanTypes = () => selections.customerType === 'New Customer' || selections.customerType === 'Existing Customer KMPL';

  const handleFindProducts = async () => {
    if (!selections.loanType || !selections.seasoningMonths) {
      setError('Please select Loan Type and Seasoning');
      return;
    }
    setIsSearching(true);
    setError('');
    try {
      const response = await axios.post(`${API_URL}/match-products`, {
        loanType: selections.loanType,
        seasoningMonths: parseInt(selections.seasoningMonths)
      });
      setMatchingProducts(response.data);
      setShowResults(true);
    } catch (err) {
      setError(err.response?.data?.error || 'Search failed');
    } finally {
      setIsSearching(false);
    }
  };

  if (!data) {
    return (
      <div className="min-h-screen bg-[#0B1727] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-4 border-emerald-500 border-t-transparent mx-auto mb-4"></div>
          <p className="text-gray-400 font-medium">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0B1727] p-4 md:p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-6">
          <div className="bg-[#1a2942] rounded-2xl shadow-2xl border border-gray-800">
            <div className="p-6 border-b border-gray-800">
              <div className="flex items-center justify-between">
                <div>
                  <h1 className="text-3xl font-bold text-emerald-400 mb-2">Welcome Ranjit Mishra to KMPL !</h1>
                  <p className="text-gray-400">One stop shop for your entire needs - do check out!</p>
                </div>
                <div className="flex items-center gap-3">
                  <div className={`px-4 py-2 rounded-lg ${backendStatus === 'connected' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'}`}>
                    <Server size={16} className="inline mr-2" />
                    {backendStatus === 'connected' ? 'Connected' : 'Offline'}
                  </div>
                </div>
              </div>
            </div>

            {/* Upload Section */}
            <div className="p-6 border-b border-gray-800">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2 text-gray-300">
                  <FileSpreadsheet size={20} />
                  <span className="font-medium">Data Source</span>
                </div>
                {isCustomData && (
                  <button onClick={handleResetData} className="px-4 py-2 bg-gray-700 text-gray-300 rounded-lg hover:bg-gray-600 transition-colors text-sm">
                    <RefreshCw size={14} className="inline mr-2" />
                    Reset
                  </button>
                )}
              </div>

              {isCustomData ? (
                <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-4">
                  <div className="flex items-center gap-3">
                    <FileSpreadsheet className="text-emerald-400" size={24} />
                    <div>
                      <p className="text-emerald-400 font-medium">Custom Excel Loaded</p>
                      <p className="text-gray-400 text-sm">{fileName}</p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-gray-800/50 border-2 border-dashed border-gray-700 rounded-lg p-6 hover:border-emerald-500/50 transition-colors">
                  <label className="flex flex-col items-center cursor-pointer">
                    <Upload className="text-gray-500 mb-2" size={32} />
                    <span className="text-gray-400 font-medium">Upload products.xlsx</span>
                    <input type="file" accept=".xlsx,.xls" onChange={handleFileUpload} className="hidden" disabled={isLoading} />
                  </label>
                </div>
              )}

              {error && (
                <div className="mt-4 bg-red-500/10 border-l-4 border-red-500 p-4 rounded">
                  <p className="text-red-400 text-sm">{error}</p>
                </div>
              )}
            </div>

            {/* Selection Form */}
            <div className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Entity *</label>
                  <select value={selections.entity} onChange={(e) => handleEntityChange(e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all">
                    <option value="">Select Entity</option>
                    {data.entities.map(e => <option key={e} value={e}>{e}</option>)}
                  </select>
                </div>

                {selections.entity && (
                  <div className="animate-fadeIn">
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Entity Type *</label>
                    <select value={selections.entityType} onChange={(e) => handleChange('entityType', e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all">
                      <option value="">Select Entity Type</option>
                      {getEntityTypes().map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                )}

                <div>
                  <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Customer Type *</label>
                  <select value={selections.customerType} onChange={(e) => handleChange('customerType', e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all">
                    <option value="">Select Customer Type</option>
                    {data.customerTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>

                {selections.entity && (
                  <div className="animate-fadeIn">
                    <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Income Category *</label>
                    <select value={selections.customerIncomeCategory} onChange={(e) => handleChange('customerIncomeCategory', e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all">
                      <option value="">Select Income Category</option>
                      {getIncomePrograms().map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                )}

                {showLoanTypes() && (
                  <>
                    <div className="animate-fadeIn">
                      <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Loan Type *</label>
                      <select value={selections.loanType} onChange={(e) => handleChange('loanType', e.target.value)} className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all">
                        <option value="">Select Loan Type</option>
                        {data.loanTypes.map(t => <option key={t} value={t}>{t}</option>)}
                      </select>
                    </div>

                    {selections.loanType && (
                      <div className="animate-fadeIn">
                        <label className="block text-xs font-semibold text-gray-400 uppercase mb-2">Seasoning (Months) *</label>
                        <input type="number" min="0" max="999" value={selections.seasoningMonths} onChange={(e) => handleChange('seasoningMonths', e.target.value)} placeholder="e.g., 6" className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-500/20 transition-all" />
                      </div>
                    )}
                  </>
                )}
              </div>

              <button onClick={handleFindProducts} disabled={!selections.loanType || !selections.seasoningMonths || isSearching} className="w-full bg-emerald-500 hover:bg-emerald-600 text-white py-4 px-6 rounded-lg font-semibold disabled:bg-gray-700 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-3">
                {isSearching ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-2 border-white border-t-transparent"></div>
                    Searching...
                  </>
                ) : (
                  <>
                    <Search size={20} />
                    Find Matching Products
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Results Section - DARK THEME LIKE AUCTION PROPERTIES */}
        {showResults && matchingProducts && (
          <div className="animate-fadeIn">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-emerald-400">
                {matchingProducts.count} Products Found
              </h2>
              <p className="text-gray-400">
                {matchingProducts.loan_type} • {matchingProducts.seasoning_months} months
              </p>
            </div>

            {matchingProducts.matching_products.length === 0 ? (
              <div className="bg-[#1a2942] rounded-2xl p-12 text-center border border-gray-800">
                <Package size={64} className="mx-auto text-gray-600 mb-4" />
                <p className="text-gray-400 text-lg">No matching products found</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                {matchingProducts.matching_products.map((product, index) => (
                  <div key={index} className="bg-[#1a2942] rounded-xl border border-gray-800 hover:border-emerald-500/50 transition-all overflow-hidden">
                    {/* Product ID Badge */}
                    <div className="p-5 pb-4">
                      <div className="inline-block px-3 py-1 bg-emerald-500/20 border border-emerald-500/30 rounded text-emerald-400 text-xs font-mono mb-4">
                        {product.product_type.toUpperCase().replace(/\s+/g, '')}
                      </div>

                      {/* Product Name */}
                      <h3 className="text-2xl font-bold text-white mb-2">
                        {product.product_name}
                      </h3>

                      {/* Status Badge */}
                      <span className={`inline-block px-3 py-1 rounded text-xs font-semibold ${
                        product.cross_sell_status === 'YES (STRONG)' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                        product.cross_sell_status === 'YES' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                        'bg-yellow-500/20 text-yellow-400 border border-yellow-500/30'
                      }`}>
                        {product.cross_sell_status}
                      </span>

                      {/* CUE - PROMINENTLY DISPLAYED */}
                      {product.cue && (
                        <div className="mt-4 p-4 bg-blue-500/10 border-l-4 border-blue-500 rounded">
                          <div className="flex items-start gap-3">
                            <span className="text-2xl">💡</span>
                            <div>
                              <p className="text-xs font-bold text-blue-400 uppercase mb-2">CUE</p>
                              <p className="text-gray-300 text-sm leading-relaxed">{product.cue}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* ACTION */}
                      {product.action && (
                        <div className="mt-3 p-4 bg-purple-500/10 border-l-4 border-purple-500 rounded">
                          <div className="flex items-start gap-3">
                            <span className="text-2xl">🎯</span>
                            <div>
                              <p className="text-xs font-bold text-purple-400 uppercase mb-2">ACTION</p>
                              <p className="text-gray-300 text-sm leading-relaxed">{product.action}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Category Info */}
                      <div className="mt-4 flex items-center gap-2 text-gray-400 text-sm">
                        <Package size={16} />
                        <span>{product.category}</span>
                      </div>
                    </div>

                    {/* Bottom Section - Like Auction Properties */}
                    <div className="border-t border-gray-800 p-4 bg-gray-900/30">
                      <div className="grid grid-cols-2 gap-4 mb-3">
                        <div>
                          <p className="text-xs text-gray-500 uppercase mb-1">Target</p>
                          <p className="text-gray-300 text-sm font-medium">{product.target_audience.substring(0, 30)}...</p>
                        </div>
                        <div>
                          <p className="text-xs text-gray-500 uppercase mb-1">Seasoning</p>
                          <p className="text-gray-300 text-sm font-medium">{product.seasoning_range}</p>
                        </div>
                      </div>

                      {/* Expandable Details */}
                      {(product.variable_reward || product.investment) && (
                        <details className="mt-3">
                          <summary className="cursor-pointer text-emerald-400 text-sm font-medium flex items-center gap-2 hover:text-emerald-300">
                            <ChevronDown size={16} />
                            More Details
                          </summary>
                          <div className="mt-3 space-y-3">
                            {product.variable_reward && (
                              <div className="bg-amber-500/10 border-l-4 border-amber-500 p-3 rounded">
                                <p className="text-xs font-bold text-amber-400 uppercase mb-1">🎁 Variable Reward</p>
                                <p className="text-gray-300 text-sm">{product.variable_reward}</p>
                              </div>
                            )}
                            {product.investment && (
                              <div className="bg-emerald-500/10 border-l-4 border-emerald-500 p-3 rounded">
                                <p className="text-xs font-bold text-emerald-400 uppercase mb-1">💼 Investment</p>
                                <p className="text-gray-300 text-sm">{product.investment}</p>
                              </div>
                            )}
                          </div>
                        </details>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.5s ease-out;
        }
      `}</style>
    </div>
  );
};

export default ProductSelector;
